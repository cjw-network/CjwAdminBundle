/*global module, require*/
(function setUp(module, require) {
  'use strict';

  require('./src/js/angular-datepicker');

  module.exports = '720kb.datepicker';
}(module, require));
