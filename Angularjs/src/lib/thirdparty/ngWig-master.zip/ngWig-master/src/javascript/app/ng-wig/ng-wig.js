/**
 * version: 2.3.3
 */
angular.module('ngWig', ['ngwig-app-templates']);
